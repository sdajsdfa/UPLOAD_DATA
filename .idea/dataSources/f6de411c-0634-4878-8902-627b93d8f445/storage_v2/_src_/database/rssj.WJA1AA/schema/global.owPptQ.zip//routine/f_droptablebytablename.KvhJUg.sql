create function f_droptablebytablename(tablename character varying, orgalias character varying, tablenameful character varying) returns void
    language plpgsql
as
$$
declare 
	icount integer;
	execute_sql varchar;
	
	BEGIN
	-- Routine body goes here...
	EXECUTE 'select count(1) from pg_tables where tablename = $1 and schemaname = $2;'
   INTO icount
   USING tablename, orgalias;
	
	if (icount > 0) then			
			execute_sql:='drop table '
        || tablenameful;				
				
			execute execute_sql; 
			
	end if ;
END
$$;

alter function f_droptablebytablename(varchar, varchar, varchar) owner to global;


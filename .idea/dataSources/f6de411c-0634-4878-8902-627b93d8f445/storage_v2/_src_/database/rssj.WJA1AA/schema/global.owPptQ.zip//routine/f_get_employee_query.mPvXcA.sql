create function f_get_employee_query() returns SETOF tab52
    language plpgsql
as
$$
begin
return query select * from tab52;
end;
$$;

alter function f_get_employee_query() owner to global;


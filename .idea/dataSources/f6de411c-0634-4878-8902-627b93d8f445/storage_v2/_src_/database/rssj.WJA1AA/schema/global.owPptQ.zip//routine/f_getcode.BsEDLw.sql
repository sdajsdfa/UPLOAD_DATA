create function f_getcode(v_storeid numeric) returns SETOF tab52
    language plpgsql
as
$$
begin
return query 
select storeid,relateddoctypeid,relateddocstoreid,opptime,knowledgeindex,value,code,isshare,validend,validbegin,kzsx,bizscope from 
(WITH RECURSIVE res(storeid,relateddoctypeid,relateddocstoreid,opptime,knowledgeindex,value,code,isshare,validend,validbegin,kzsx,bizscope,depth) AS (
  SELECT t1.*,1 FROM tab52 as t1  
   WHERE t1.relateddocstoreid = v_storeid 
   UNION 
         SELECT t2.*,t3.depth+1 from tab52 as t2
     INNER JOIN res as t3 ON t3.storeid = t2.relateddocstoreid

 )SELECT res.* from res order by depth,relateddocstoreid,knowledgeindex) codet;
end;
$$;

alter function f_getcode(numeric) owner to global;


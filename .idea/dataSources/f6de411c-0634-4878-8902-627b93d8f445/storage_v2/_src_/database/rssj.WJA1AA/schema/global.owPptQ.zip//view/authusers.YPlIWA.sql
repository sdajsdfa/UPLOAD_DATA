create view authusers(canonical, alias, loginpwd, deptname, deptnamecode) as
SELECT p.canonical,
       p.alias,
       p.loginpwd,
       d.canonical AS deptname,
       d.code      AS deptnamecode
FROM tab1 p
         LEFT JOIN tab2 d ON d.storeid = p.relateddocstoreid
WHERE p.alias::text <> 'admin'::text
  AND p.alias::text <> 'rssj'::text;

alter table authusers
    owner to global;


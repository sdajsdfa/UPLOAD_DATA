create view dual(unknown) as
SELECT NULL::text AS unknown
WHERE 1 = 1;

alter table dual
    owner to global;


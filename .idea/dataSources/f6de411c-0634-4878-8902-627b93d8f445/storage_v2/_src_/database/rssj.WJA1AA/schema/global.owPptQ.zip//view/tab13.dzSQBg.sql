create view tab13
            (storeid, relateddoctypeid, relateddocstoreid, operatename, oppid, opptime, doctypeid, doctypename,
             catalogname, docattribute, doctypeindex)
as
SELECT doctypeid                         AS storeid,
       0                                 AS relateddoctypeid,
       0                                 AS relateddocstoreid,
       NULL::character varying           AS operatename,
       NULL::character varying           AS oppid,
       NULL::timestamp without time zone AS opptime,
       doctypeid,
       doctypename,
       catalogname,
       docattribute,
       doctypeindex
FROM doctype;

alter table tab13
    owner to global;


create view tab139
            (storeid, relateddoctypeid, relateddocstoreid, opptime, canonical, alias, directmanager, isremote, orglevel,
             orgindex, xzqhdm, zsdwdm, zsjb, zwjc, validbegin, validend, isexchanged)
as
SELECT tab3.storeid,
       tab3.relateddoctypeid,
       tab3.relateddocstoreid,
       tab3.opptime,
       tab3.canonical,
       tab3.alias,
       tab3.directmanager,
       tab3.isremote,
       tab3.orglevel,
       tab3.orgindex,
       tab3.xzqhdm,
       tab3.zsdwdm,
       tab3.zsjb,
       tab3.zwjc,
       tab3.validbegin,
       tab3.validend,
       tab3.isexchanged
FROM tab3
UNION
SELECT tab137.storeid,
       tab137.relateddoctypeid,
       tab137.relateddocstoreid,
       tab137.opptime,
       tab137.canonical,
       tab137.alias,
       tab137.directmanager,
       tab137.isremote,
       tab137.orglevel,
       tab137.orgindex,
       tab137.xzqhdm,
       tab137.zsdwdm,
       tab137.zsjb,
       tab137.zwjc,
       tab137.validbegin,
       tab137.validend,
       tab137.isexchanged
FROM tab137;

alter table tab139
    owner to global;


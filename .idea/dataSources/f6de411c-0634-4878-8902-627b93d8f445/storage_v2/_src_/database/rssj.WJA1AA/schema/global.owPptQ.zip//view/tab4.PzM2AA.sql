create view tab4
            (storeid, relateddoctypeid, relateddocstoreid, opptime, groupname, grouplevel, class, groupindex,
             isshare) as
SELECT tab19.storeid,
       tab19.relateddoctypeid,
       tab19.relateddocstoreid,
       tab19.opptime,
       tab19.groupname,
       tab19.grouplevel,
       tab19.class,
       tab19.groupindex,
       1 AS isshare
FROM tab19
UNION ALL
SELECT tab20.storeid,
       tab20.relateddoctypeid,
       tab20.relateddocstoreid,
       tab20.opptime,
       tab20.groupname,
       tab20.grouplevel,
       tab20.class,
       tab20.groupindex,
       0 AS isshare
FROM tab20;

alter table tab4
    owner to global;


create view tab47
            (storeid, relateddoctypeid, relateddocstoreid, opptime, knowledgeindex, value, code, isshare, validend,
             validbegin, kzsx, bizscope)
as
SELECT tab52.storeid,
       tab52.relateddoctypeid,
       tab52.relateddocstoreid,
       tab52.opptime,
       tab52.knowledgeindex,
       tab52.value,
       tab52.code,
       tab52.isshare,
       tab52.validend,
       tab52.validbegin,
       tab52.kzsx,
       tab52.bizscope
FROM tab52
UNION
SELECT tab45.storeid,
       tab45.relateddoctypeid,
       tab45.relateddocstoreid,
       tab45.opptime,
       tab45.knowledgeindex,
       tab45.value,
       tab45.code,
       tab45.isshare,
       tab45.validend,
       tab45.validbegin,
       tab45.kzsx,
       tab45.bizscope
FROM tab45;

alter table tab47
    owner to global;


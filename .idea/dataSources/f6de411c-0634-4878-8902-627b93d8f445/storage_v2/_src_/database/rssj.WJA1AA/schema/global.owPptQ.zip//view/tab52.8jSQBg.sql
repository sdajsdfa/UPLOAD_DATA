create view tab52
            (storeid, relateddoctypeid, relateddocstoreid, opptime, knowledgeindex, value, code, isshare, validend,
             validbegin, kzsx, bizscope)
as
SELECT tab48.storeid,
       CASE tab48.relateddoctypeid
           WHEN 48 THEN 52::numeric
           WHEN 49 THEN 52::numeric
           ELSE tab48.relateddoctypeid
           END AS relateddoctypeid,
       tab48.relateddocstoreid,
       tab48.opptime,
       tab48.knowledgeindex,
       tab48.value,
       tab48.code,
       tab48.isshare,
       tab48.validend,
       tab48.validbegin,
       tab48.kzsx,
       tab48.bizscope
FROM tab48
UNION
SELECT tab49.storeid,
       CASE tab49.relateddoctypeid
           WHEN 48 THEN 52::numeric
           WHEN 49 THEN 52::numeric
           ELSE tab49.relateddoctypeid
           END AS relateddoctypeid,
       tab49.relateddocstoreid,
       tab49.opptime,
       tab49.knowledgeindex,
       tab49.value,
       tab49.code,
       tab49.isshare,
       tab49.validend,
       tab49.validbegin,
       tab49.kzsx,
       tab49.bizscope
FROM tab49;

alter table tab52
    owner to global;


create view tab68
            (storeid, relateddoctypeid, relateddocstoreid, opptime, dayoffname, ismonrest, istuesrest, iswederest,
             isthurest, isfrirest, issatrest, issunrest)
as
SELECT 1                    AS storeid,
       NULL::text           AS relateddoctypeid,
       NULL::text           AS relateddocstoreid,
       CURRENT_TIMESTAMP(2) AS opptime,
       '???'::text          AS dayoffname,
       0                    AS ismonrest,
       0                    AS istuesrest,
       0                    AS iswederest,
       0                    AS isthurest,
       0                    AS isfrirest,
       1                    AS issatrest,
       1                    AS issunrest
FROM dual;

alter table tab68
    owner to global;


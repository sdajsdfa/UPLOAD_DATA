create view tab8
            (storeid, relateddoctypeid, relateddocstoreid, opptime, rolename, template, rolenumber, catalogname,
             isshare) as
SELECT tab17.storeid,
       tab17.relateddoctypeid,
       tab17.relateddocstoreid,
       tab17.opptime,
       tab17.rolename,
       tab17.template,
       tab17.rolenumber,
       tab17.catalogname,
       1 AS isshare
FROM tab17
UNION ALL
SELECT tab18.storeid,
       tab18.relateddoctypeid,
       tab18.relateddocstoreid,
       tab18.opptime,
       tab18.rolename,
       tab18.template,
       tab18.rolenumber,
       tab18.catalogname,
       0 AS isshare
FROM tab18;

alter table tab8
    owner to global;


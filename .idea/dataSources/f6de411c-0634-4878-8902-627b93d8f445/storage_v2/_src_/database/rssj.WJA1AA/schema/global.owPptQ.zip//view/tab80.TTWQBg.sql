create view tab80
            (storeid, relateddoctypeid, relateddocstoreid, operatename, opptime, oppid, catalogname, maindoctypename,
             maindoctypeid)
as
SELECT doctypeid                         AS storeid,
       0                                 AS relateddoctypeid,
       0                                 AS relateddocstoreid,
       NULL::text                        AS operatename,
       NULL::timestamp without time zone AS opptime,
       NULL::text                        AS oppid,
       catalogname,
       doctypename                       AS maindoctypename,
       doctypeid                         AS maindoctypeid
FROM doctype;

alter table tab80
    owner to global;


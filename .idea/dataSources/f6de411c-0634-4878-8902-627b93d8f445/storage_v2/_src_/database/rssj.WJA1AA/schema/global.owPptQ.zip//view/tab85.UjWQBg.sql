create view tab85 (storeid, relateddoctypeid, relateddocstoreid, opptime, itemdoctype, datascopetpl) as
SELECT tab83.storeid,
       93 AS relateddoctypeid,
       tab83.relateddocstoreid,
       tab83.opptime,
       tab83.itemdoctype,
       tab83.datascopetpl
FROM tab83
UNION
SELECT tab84.storeid,
       93 AS relateddoctypeid,
       tab84.relateddocstoreid,
       tab84.opptime,
       tab84.itemdoctype,
       tab84.datascopetpl
FROM tab84;

alter table tab85
    owner to global;


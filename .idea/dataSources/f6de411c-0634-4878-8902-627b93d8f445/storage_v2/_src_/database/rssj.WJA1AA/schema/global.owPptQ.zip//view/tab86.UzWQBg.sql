create view tab86
            (storeid, relateddoctypeid, relateddocstoreid, opptime, doctype, fieldname, operate, value, linkorder,
             linktype) as
SELECT tab95.storeid,
       85 AS relateddoctypeid,
       tab95.relateddocstoreid,
       tab95.opptime,
       tab95.doctype,
       tab95.fieldname,
       tab95.operate,
       tab95.value,
       tab95.linkorder,
       tab95.linktype
FROM tab95
UNION
SELECT tab96.storeid,
       85 AS relateddoctypeid,
       tab96.relateddocstoreid,
       tab96.opptime,
       tab96.doctype,
       tab96.fieldname,
       tab96.operate,
       tab96.value,
       tab96.linkorder,
       tab96.linktype
FROM tab96;

alter table tab86
    owner to global;


create view tab93 (storeid, relateddoctypeid, relateddocstoreid, opptime, rolealias, functionalias, roleindex) as
SELECT tab101.storeid,
       tab101.relateddoctypeid,
       tab101.relateddocstoreid,
       tab101.opptime,
       tab101.rolealias,
       tab101.functionalias,
       tab101.roleindex
FROM tab101
UNION
SELECT tab102.storeid,
       tab102.relateddoctypeid,
       tab102.relateddocstoreid,
       tab102.opptime,
       tab102.rolealias,
       tab102.functionalias,
       tab102.roleindex
FROM tab102;

alter table tab93
    owner to global;


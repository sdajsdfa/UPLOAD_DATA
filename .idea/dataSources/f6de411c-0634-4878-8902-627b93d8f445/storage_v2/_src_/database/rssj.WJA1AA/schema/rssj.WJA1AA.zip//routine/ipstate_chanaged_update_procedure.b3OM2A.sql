create function ipstate_chanaged_update_procedure() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
	IF NEW.ipstate = '02' AND OLD.ipstate = '01' THEN
			INSERT INTO gisshow.tab210080 VALUES (nextval( 'storeid_sequence' ), NULL, NULL, NOW(), NEW.ip, NOW(), NULL, NEW.linename, '0' );
  END IF;
	IF NEW.ipstate = '01' AND OLD.ipstate = '02' THEN
				UPDATE gisshow.tab210080  SET endtime = now()  WHERE ip = OLD.ip AND endtime IS NULL;
	END IF;
	RETURN NEW;
END;
$$;

alter function ipstate_chanaged_update_procedure() owner to global;


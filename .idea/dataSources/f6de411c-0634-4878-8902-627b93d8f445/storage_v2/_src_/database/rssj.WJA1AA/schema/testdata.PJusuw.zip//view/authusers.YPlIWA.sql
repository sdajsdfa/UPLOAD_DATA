create view authusers(canonical, alias, loginpwd, deptname, deptnamecode) as
SELECT canonical,
       alias,
       loginpwd,
       deptname,
       deptnamecode
FROM authusers;

alter table authusers
    owner to global;

